package com.davidson.strangers.util

class Constants {
    companion object{
        const val BASE_URL = "https://randomuser.me/"
        const val NUMBER_OF_USER_TO_FETCH = 10
        const val TIRED_TAG = "Tired"
        const val API_WEATHER_KEY_1 = "70bdc34e8f27487dbfbfce3104890f79"
        const val API_WEATHER_KEY_2 = "532e61560fc8468bb9fda40e97b4856c"
    }
}